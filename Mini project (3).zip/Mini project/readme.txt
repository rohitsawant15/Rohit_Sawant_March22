###########################This program is for weather board management###########################

1.Program is divided in 2 parts:  i)Admin (Who will upload/feed data in system.)
								  ii)User (Who can read only today's weather.)
								
2.When we load program 1st it will ask for password to enter in Admin mode.(Password is : admin).

3.If we enter wrong password it will direct jump of next part: User mode i.e. we have only one chance for correct password.

4.After entering correct password it will successfully login in Admin mode.

5.It will ask city for entering today's weather data.

6.After entering all data it will ask again for next city for entering new data.(We can overwrite data for same city.)

7.If we want exit admin mode enter 0.

8.Then it will ask for password to enter in User mode.(Password is : cdac2022).
Here also we have only one chance for correct password.Otherwise program will get terminate.   

9.It will ask for enter city to see today's weather.

10.Further enter next city for weather or Enter 0 for terminate the program.


Legends:								
Admin part
User part								


//static method
//Encapsulation
//Abstraction
//inheritance
//ArrayList //Array of Objects
//Loops
//Switch case